#!/bin/bash

trap 'onCtrlC' INT
function onCtrlC () {
        #捕获CTRL+C，当脚本被ctrl+c的形式终止时同时终止程序的后台进程
        kill -9 ${do_sth_pid} ${progress_pid}
        echo
        echo 'Ctrl+C is captured'
        exit 1
}

do_sth() {
        #运行的主程序
        sudo apt update > /dev/null 2>&1
        sudo apt upgrade -y > /dev/null 2>&1
        sudo apt install curl -y > /dev/null 2>&1
        sudo apt install rsync -y > /dev/null 2>&1
        sudo apt install zip -y > /dev/null 2>&1
        sudo apt install git python python3 brotli e2fsprogs zip -y > /dev/null 2>&1
}

progress() {
        #进度条程序
        local main_pid=$1
        local length=20
        local ratio=1
        while [ "$(ps -p ${main_pid} | wc -l)" -ne "1" ] ; do
                mark='#'
                progress_bar=
                for i in $(seq 1 "${length}"); do
                        if [ "$i" -gt "${ratio}" ] ; then
                                mark='●'
                        fi
                        progress_bar="${progress_bar}${mark}"
                done
                printf "\033[0;32m---${progress_bar}\e[m\r"
                ratio=$((ratio+1))
                #ratio=`expr ${ratio} + 1`
                if [ "${ratio}" -gt "${length}" ] ; then
                        ratio=1
                fi
                sleep 0.1
        done
}

do_sth &
do_sth_pid=$(jobs -p | tail -1)

progress "${do_sth_pid}" &
progress_pid=$(jobs -p | tail -1)

wait "${do_sth_pid}"
printf "\033[0;32m---初始化完成                \e[m\n"
