#!/bin/bash
echo -e "$ge上传到gof$cz"
curl -sL https://git.io/file-transfer | sh
./transfer gof $wk/MIUi12.5_olive.zip
#log
./transfer gof $wk/log.zip