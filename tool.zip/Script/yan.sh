#!/bin/bash
red="\x1B[31m" #红
og="\x1B[01;91m" #橙
ge="\x1B[32m" #绿
cz="\x1B[0m"
export yan=`curl -s "https://v1.jinrishici.com/all.json"`
export content=`printf "$yan\n" | grep "content" | sed 's/\(.*\)"\(.*\)"\(.*\)/\2/g'`
export origin=`printf "$yan\n" | grep "origin" | sed 's/\(.*\)"\(.*\)"\(.*\)/\2/g'`