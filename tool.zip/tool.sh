#!/bin/bash
clear
export M=$(cd $(dirname $0);pwd)
export bin=$M/bin
export wk=$M/Work
export sub=$M/Sub
#初始化
echo -e "---初始化环境"
sudo apt update > /dev/null 2>&1
sudo apt upgrade -y > /dev/null 2>&1
sudo apt install curl -y > /dev/null 2>&1
sudo apt install rsync -y > /dev/null 2>&1
sudo apt install zip -y > /dev/null 2>&1
sudo apt install git python python3 brotli e2fsprogs zip -y > /dev/null 2>&1
mkdir $M/Work
chmod 777 -R $bin

#解包---------------
name=$(zip=`find ${M}/*.zip` && zip=`echo ${zip##*/}` && echo ${zip%.zip*})
n="$wk/$name"
z=$(find ${M}/*.zip)
mkdir $wk/$name && unzip -q $z -d $wk/$name

#br转dat
echo -e "\n---system.new.dat.br转system.new.dat${cz}"
brotli -d $wk/$name/system.new.dat.br -o $wk/$name/system.new.dat
echo -e "---vendor.new.dat.br转vendor.new.dat${cz}"
brotli -d $wk/$name/vendor.new.dat.br -o $wk/$name/vendor.new.dat
rm -rf $wk/$name/system.new.dat.br
rm -rf $wk/$name/system.new.dat.br

#dat转img
echo -e "---system.new.dat转system.img"
$bin/sdat2img/sdat2img.py $n'/'system.transfer.list $n'/'system.new.dat $n'/'system.img > /dev/null 2>&1&& rm -rf $wk/$name/system.transfer.list && rm -rf $wk/$name/system.new.dat
echo -e "---vendor.new.dat转vendor.img"
$bin/sdat2img/sdat2img.py $n'/'vendor.transfer.list $n'/'vendor.new.dat $n'/'vendor.img > /dev/null 2>&1&& rm -rf $wk/$name/vendor.transfer.list && rm -rf $wk/$name/vendor.new.dat
ssize=$(expr $(ls -al ${n}/system.img | awk '{print $5}') / 1024 / 1024 )
vsize=$(expr $(ls -al ${n}/vendor.img | awk '{print $5}') / 1024 / 1024 )
#调整img大小
echo -e "---调整system大小"
e2fsck -fy $n/system.img > /dev/null 2>&1
resize2fs -f $n/system.img 4096m > /dev/null 2>&1
echo -e "---调整vendor大小"      
e2fsck -fy $n/vendor.img > /dev/null 2>&1
resize2fs -f $n/vendor.img 2048m > /dev/null 2>&1
#解img
echo -e "---解压system.img" && python3 $bin/imgextractor/imgextractor.py $n/system.img $n  > /dev/null 2>&1 && rm -rf ${n}/system.img
echo -e "---解压vendor.img" && python3 $bin/imgextractor/imgextractor.py $n/vendor.img $n > /dev/null 2>&1 && rm -rf ${n}/vendor.img
#判断是否执行插件
if [[ -n $(ls $M/Sub) ]];then
    for s in $(ls $sub)
    do
        rm -rf $sub/log
        echo "执行$s插件"
        source ${sub}/${s}/run.sh >> $sub/$s.txt
    done
    if [[ ! -d $sub/log ]];then
        mkdir $sub/log
        mv $sub/*.txt $wk
    fi
fi
#打包---------------
#打包system，vendor
echo -e "---打包system${cz}"
ssize=$(cat ${n}/config/system_size.txt)
size=$(expr $ssize / 1024 / 1024 )
$bin/mke2fs -L / -t ext4 -b 4096 $n/system.img ${size}M > /dev/null 2>&1
$bin/e2fsdroid -e -T 0 -S $n/config/system_file_contexts -C $n/config/system_fs_config  -a /system -f $n/system $n/system.img > /dev/null 2>&1&& rm -rf $n/system
echo -e "---打包vendor${cz}"
ssize=$(cat ${n}/config/vendor_size.txt)
size=$(expr $ssize / 1024 / 1024 )
$bin/mke2fs -L / -t ext4 -b 4096 $n/vendor.img ${size}M   
$bin/e2fsdroid -e -T 0 -S $n/config/vendor_file_contexts -C $n/config/vendor_fs_config  -a /vendor -f $n/vendor $n/vendor.img > /dev/null 2>&1&& rm -rf $n/vendor
#img转dat
echo -e "---system.img转system.new.dat"
$bin/rimg2sdat.py $n/system.img -o $n -v 4 > /dev/null 2>&1
rm -rf ${n}/system.img
echo -e "---vendor.img转vendor.new.dat"
$bin/rimg2sdat.py ${n}/vendor.img -o $wk -v 4 > /dev/null 2>&1
mv $wk/system.new.dat  $n/vendor.new.dat && mv $wk/system.transfer.list $n/vebdor.transfer.list
rm -rf ${n}/vendor.img
#dat转br
echo -e "system.new.dat转system.new.dat.br"
brotli -q 4 ${n}/system.new.dat -o $n/system.new.dat.br
rm -rf ${n}/system.new.dat
echo -e "vendor.new.dat转vendor.new.dat.br"
brotli -q 4 ${n}/vendor.new.dat -o $n/vendor.new.dat.br
rm -rf ${n}/vendor.new.dat
echo -e "---打包Rom"
rm -rf ${n}/system.new.dat
rm -rf ${n}/vendor.new.dat
rm -rf ${n}/config
cd $n
zip -q -r $wk/MIUi12.5_olive.zip ./*
cd $M
rm -rf $n
mv $M/Recover.zip $wk
mv $sub/log/* $wk
cd $wk
zip -q -r ./log.zip ./*.txt
cd $M
source $M/Script/Upload.sh
